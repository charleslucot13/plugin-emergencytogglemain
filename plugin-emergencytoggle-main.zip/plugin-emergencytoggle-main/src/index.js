import * as FlexPlugin from 'flex-plugin';

import EmergencytogglePlugin from './EmergencytogglePlugin';

FlexPlugin.loadPlugin(EmergencytogglePlugin);
